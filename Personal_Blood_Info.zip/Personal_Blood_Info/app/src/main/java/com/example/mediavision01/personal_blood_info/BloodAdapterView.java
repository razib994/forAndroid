package com.example.mediavision01.personal_blood_info;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class BloodAdapterView extends RecyclerView.Adapter<BloodAdapterView.BloodViewHolder> {
    private List<Blood_Person_Info> blood_person_infos;
    Context context;

    public BloodAdapterView(List<Blood_Person_Info> blood_person_infos, Context context) {
        this.blood_person_infos = blood_person_infos;
        this.context = context;
    }

    @Override
    public BloodViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View views = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_user_recycler,parent,false);
        BloodViewHolder bloodViewHolder = new BloodViewHolder(views,context, (ArrayList<Blood_Person_Info>) blood_person_infos);
        return bloodViewHolder;
    }

    @Override
    public void onBindViewHolder(BloodViewHolder holder, int position) {
        holder.nameTV.setText(blood_person_infos.get(position).getBloodpersonName());
        holder.addressTV.setText(blood_person_infos.get(position).getBloodpersonAddress());
        holder.bloodGroupTV.setText(blood_person_infos.get(position).getPersonBloodGroup());


    }

    @Override
    public int getItemCount() {
        return blood_person_infos.size();
    }

    public class BloodViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView nameTV,emailTV,phoneTV,addressTV,genderTV,bloodGroupTV,dateofBirthTV;
        List<Blood_Person_Info> blood_person_infos = new ArrayList<Blood_Person_Info>();
        Context context;
        public BloodViewHolder(View itemView, Context context, ArrayList<Blood_Person_Info> blood_person_infos) {
            super(itemView);
            this.blood_person_infos = blood_person_infos;
            this.context = context;
            itemView.setOnClickListener(this);
            nameTV = itemView.findViewById(R.id.textViewName);
            addressTV = itemView.findViewById(R.id.textaddress);
            bloodGroupTV = itemView.findViewById(R.id.textViewBloodGroup);
        }

        @Override
        public void onClick(View view) {
            int position =  getAdapterPosition();
            Blood_Person_Info blood_person_info = this.blood_person_infos.get(position);
            Intent intent = new Intent(this.context,DetailsPersonActivity.class);
            //intent.getSerializableExtra("blood",blood_person_info);
            intent.putExtra("id",blood_person_info.getId());
            intent.putExtra("name",blood_person_info.getBloodpersonName());
            intent.putExtra("email",blood_person_info.getBloodpersonEmail());
            intent.putExtra("phone",blood_person_info.getBloodpersonPhone());
            intent.putExtra("gender",blood_person_info.getBloodpersongender());
            intent.putExtra("dateofBirth",blood_person_info.getBloodpersondateofbirth());
            intent.putExtra("address",blood_person_info.getBloodpersonAddress());
            intent.putExtra("groupBlood",blood_person_info.getPersonBloodGroup());
            this.context.startActivity(intent);



        }
    }
}
