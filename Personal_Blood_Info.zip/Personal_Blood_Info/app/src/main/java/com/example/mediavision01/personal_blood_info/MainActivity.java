package com.example.mediavision01.personal_blood_info;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
private RecyclerView recyclerView;
private List<Blood_Person_Info>blood_person_infos = new ArrayList<>();
private  BloodAdapterView bloodAdapterView;
private Blood_Person_DatabaseSource blood_person_databaseSource = new Blood_Person_DatabaseSource(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        blood_person_infos = Blood_Person_Info.getBloodPerson();
        if(blood_person_infos.size() == 0){
            ((TextView)findViewById(R.id.emptyListMsg)).setVisibility(View.VISIBLE);
        }
        recyclerView = findViewById(R.id.recyclerViewUsers);

        bloodAdapterView = new BloodAdapterView(blood_person_infos,this);
        RecyclerView.LayoutManager mlayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mlayoutManager);
        recyclerView.setAdapter(bloodAdapterView);
        getDataFromSQLite();
    }

    private void getDataFromSQLite() {
        // AsyncTask is used that SQLite operation not blocks the UI Thread.
        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                blood_person_infos.clear();
                blood_person_infos.addAll(blood_person_databaseSource.getBloodInfo());

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);

            }
        }.execute();
    }
    public void addNewEmployee(View view) {
        Intent intent = new Intent(MainActivity.this,RegistrationActivity.class);
        startActivity(intent);
    }

    public void RecyclerViewInit(View view) {

   Intent intent = new Intent(this,DetailsPersonActivity.class);
   startActivity(intent);

    }
}
