package com.example.mediavision01.personal_blood_info;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Parcelable;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class RegistrationActivity extends AppCompatActivity {
private Button dateofBirthBT;
private Spinner spinnerSp;
private String gender ="Male",bloodGroup;
private RadioGroup buttonRG;

    private List<Blood_Person_Info> bloodPersonInfos;
private TextInputEditText textInputEditTextName, textInputEditTextEmail, textInputEditTextPhone, textInputEditTextAddress;
    private final Blood_Person_DatabaseSource blood_person_databaseSource = new Blood_Person_DatabaseSource(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        // DatePikerDialog ====================
        dateofBirthBT = findViewById(R.id.dateofBirthBT);

        // RadioGroup Button ==============
        buttonRG = findViewById(R.id.radioGroupGender);

        // Spinner =============================
        spinnerSp = findViewById(R.id.bloodGroupSP);

        // TextInputEditText ===================
        textInputEditTextName = findViewById(R.id.textInputEditTextName);
        textInputEditTextEmail = findViewById(R.id.textInputEditTextEmail);
        textInputEditTextPhone = findViewById(R.id.textInputEditTextPhone);
        textInputEditTextAddress = findViewById(R.id.textInputEditTextAddress);

        // datePikerDialog ==============================================
        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);
        dateofBirthBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(RegistrationActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        dateofBirthBT.setText(day+"-"+(month+1)+"-"+year);
                    }
                }, year, month, day);
                datePickerDialog.show();

            }
        });
        // End of DatePikerDialog =================================
        // Spinner  =======================================
        ArrayAdapter<String> adapterView = new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item,getBlood());
        spinnerSp.setAdapter(adapterView);
        spinnerSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                bloodGroup = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        // End of Spinner =================================

        // Radio button Gender ======================
        buttonRG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton rbGender = findViewById(i);
                gender = rbGender.getText().toString();
            }
        });

    }
    // Spinner Method ===========
    private  List<String> getBlood(){
        List<String> blood = new ArrayList<>();
        blood.add("A+");
        blood.add("B+");
        blood.add("O+");
        blood.add("AB+");
        blood.add("A-");
        blood.add("B-");
        blood.add("O-");
        blood.add("AB-");
        return blood;
    }
    // End Spinner Method ===========


// Submit button Information ===========================
    public void bloodInfoPersonRegistration(View view) {
        String name = textInputEditTextName.getText().toString();
        String email = textInputEditTextEmail.getText().toString();
        String phone = textInputEditTextPhone.getText().toString();
        String address = textInputEditTextAddress.getText().toString();
        String date = dateofBirthBT.getText().toString();

        Blood_Person_Info blood_person_info = new Blood_Person_Info(name,email,phone,gender,date,address,bloodGroup);


        if (blood_person_databaseSource.savePersonInfo(blood_person_info))
        {
            Intent intent = new Intent(this,MainActivity.class);
            startActivity(intent);

        }
        else
        {
            Toast.makeText(this, "Not Saved", Toast.LENGTH_SHORT).show();
        }


    }

}
